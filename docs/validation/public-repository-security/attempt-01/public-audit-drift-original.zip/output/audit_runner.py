import datetime, hashlib, json, pathlib, subprocess, time
ROOT=pathlib.Path('/Users/elviszoz/.codex/worktrees/c379/versat-ai-harness')
PROJECT=pathlib.Path('/private/tmp/versat-public-security-scenarios-r1/public-audit-drift/project')
OUT=PROJECT.parent/'output'
PYTHON='/private/tmp/versat-security-audit-venv/bin/python'
ENV={'PATH':'/usr/bin:/bin:/usr/sbin:/sbin','PYTHONDONTWRITEBYTECODE':'1','TMPDIR':str(OUT)}
def now(): return datetime.datetime.now(datetime.timezone.utc).isoformat()
def manifest(): return {str(p.relative_to(PROJECT)):hashlib.sha256(p.read_bytes()).hexdigest() for p in sorted(PROJECT.rglob('*')) if p.is_file()}
before=manifest(); (OUT/'project-before.json').write_text(json.dumps(before,indent=2)+'\n')
def run(name,argv,cwd=ROOT):
    start=now(); tick=time.monotonic()
    result=subprocess.run(argv,cwd=cwd,env=ENV,stdin=subprocess.DEVNULL,capture_output=True,text=True,timeout=60)
    record={'argv':argv,'cwd':str(cwd),'started_at':start,'finished_at':now(),'duration_seconds':time.monotonic()-tick,'exit_code':result.returncode,'stdout':result.stdout,'stderr':result.stderr,'environment':ENV}
    (OUT/(name+'.command.json')).write_text(json.dumps(record,indent=2)+'\n')
    print(name, result.returncode, result.stdout[:300],result.stderr[:300],flush=True)
run('01-policy',[PYTHON,'-B',str(ROOT/'validators/security/validate.py'),'--check-policy','--output',str(OUT/'policy.json')])
run('02-locked-provider',[PYTHON,'-B',str(ROOT/'scripts/testing/provider.py'),'--root',str(PROJECT)])
run('03-locked-snapshot',[PYTHON,'-B',str(ROOT/'validators/security/validate.py'),'--repository','example-owner/security-fixture','--project-root',str(PROJECT),'--snapshot',str(PROJECT/'inputs/settings.json'),'--output',str(OUT/'locked-snapshot.json')])
run('04-source-snapshot',[PYTHON,'-B',str(ROOT/'validators/security/validate.py'),'--repository','example-owner/security-fixture','--snapshot',str(PROJECT/'inputs/settings.json'),'--output',str(OUT/'source-snapshot.json')])
run('05-local-tests',[PYTHON,'-B','-m','unittest','discover','-s',str(PROJECT/'tests'),'-p','test_*.py','-v'],PROJECT)
run('06-validation-config',[PYTHON,'-B',str(ROOT/'validators/testing/validate.py'),'--root',str(PROJECT)])
run('07-sdd',[PYTHON,'-B',str(ROOT/'validators/sdd/validate.py'),'--root',str(PROJECT),'--json'])
run('08-remote-identity',["git","-C",str(PROJECT),"remote","-v"])
run('09-record-inputs',['/bin/cat',str(ROOT/'skills/project-audit/SKILL.md'),str(ROOT/'tests/skills/security/public-audit-drift.md'),str(PROJECT/'AGENTS.md'),str(PROJECT/'inputs/context.json'),str(PROJECT/'.versat/project.yaml'),str(PROJECT/'.versat/standards.lock'),str(ROOT/'standards/index.yaml'),str(ROOT/'docs/guides/public-repository-security.md')])
# Independently compare index resolution and file digests; this is supplementary analysis, not the official clean-provider verifier.
import yaml
index=yaml.safe_load((ROOT/'standards/index.yaml').read_text()); identity=yaml.safe_load((PROJECT/'.versat/project.yaml').read_text()); lock=yaml.safe_load((PROJECT/'.versat/standards.lock').read_text()); p=identity['project']
expected=set(index['core']['always'])
for group,key in [('profiles',p['profile']),('domains',p['domain']),('criticality',p['criticality'])]: expected.update(index[group][key])
for tech in identity['technologies']: expected.update(index['technologies'][tech])
rows=lock['standards']; version=(ROOT/'VERSION').read_text().strip()
analysis={'kind':'manual supplementary comparison using canonical index','expected_paths':sorted(expected),'missing':sorted(expected-{r['path'] for r in rows}),'extra':sorted({r['path'] for r in rows}-expected),'duplicates':len(rows)!=len({r['path'] for r in rows}),'version':version,'standards':[{**r,'actual_digest':hashlib.sha256((ROOT/'standards'/r['path']).read_bytes()).hexdigest(),'matches':r['version']==version and r['digest']==hashlib.sha256((ROOT/'standards'/r['path']).read_bytes()).hexdigest()} for r in rows],'provider_identity_limit':'Development source digest binding verified by coordinator; clean release identity not established.'}
(OUT/'index-lock-comparison.json').write_text(json.dumps(analysis,indent=2)+'\n')
after=manifest(); (OUT/'project-after.json').write_text(json.dumps(after,indent=2)+'\n'); (OUT/'preservation.json').write_text(json.dumps({'project_files_unchanged':before==after,'before_files':len(before),'after_files':len(after),'provider_preservation':'Independent coordinator baseline and final digest comparison required.'},indent=2)+'\n')
print('index matches',not analysis['missing'] and not analysis['extra'] and all(r['matches'] for r in analysis['standards']),'project unchanged',before==after)
