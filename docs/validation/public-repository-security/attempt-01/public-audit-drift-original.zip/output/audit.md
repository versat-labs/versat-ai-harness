# Public repository security audit

The supplied synthetic snapshot is non-compliant. The actual version-matched verifier returns `fail`, exit 1, `mode: snapshot`, and `public_ready: false`. No current GitHub compliance or release readiness is established.

## Findings

| Severity | Finding and evidence | Contract | Concrete remediation |
| --- | --- | --- | --- |
| High | Stale review dismissal is disabled in `inputs/settings.json` at `observations.protection.data.required_pull_request_reviews.dismiss_stale_reviews`. Verifier control `main.dismiss_stale_reviews` fails with `missing-no-bypass-guarantee`. | Indexed `core/git.md` and `core/public-repository-security.yaml`, `main.review_flags.dismiss_stale_reviews: true`. | Through a separately authorized reviewed administration change, enable stale review dismissal for main without administrator or actor bypass. Preserve owner review, last-push approval, administrator enforcement, strict checks and `custom-required-check`. Read back live settings. |
| High | Repository secret push protection is explicitly disabled at `observations.repository.data.security_and_analysis.secret_scanning_push_protection.status`. Verifier control `secrets.secret_scanning_push_protection` fails. | Indexed `core/security.md` and public security YAML require repository-level secret scanning and push protection. | Through separately authorized administration, enable repository push protection, retain existing secret scanning, and verify the repository-level status with the exact provider's live verifier. |
| Medium, execution gap | `.versat/validation.yaml` is absent; the configuration validator returns exit 1. The two available unit tests pass but execute a helper defined inside the test file; they do not establish a complete product suite or CI integration. | Indexed `core/testing.md`, `technologies/python.md`; executor configuration requirement applies upon executor adoption. | Decide and record executor adoption, then define a reviewed required-suite configuration and documented test entry point covering the actual library behavior, errors and boundaries. Verify CI separately. Do not equate this fixture's tests with product readiness. |

## Provider and identity limits

The fixture declares `library`, `finance`, `medium`, `public`, Python, and provider 0.4.0. Manual canonical-index comparison confirms all 14 expected Standards paths, versions and content digests match, with no missing, extra or duplicate entries (`index-lock-comparison.json`).

The development lock is `development-snapshot:7da6a45b4827fc6805d3966cbddb7e13fb937dac3fcaa27abf21e6fbf5b50cef`, not a published clean release. The strict official provider resolver returns exit 2: `Expected exact provider version and full commit in standards.lock`. Accordingly the separately retained locked-consumer snapshot attempt returns `unable-to-verify` and `public_ready: false`; it was not repaired or hidden. Direct source assessment is permitted for this explicitly recorded development fixture. The report identifies version 0.4.0, commit `c191f3b126c659fbabfd4ed3d40b474407cfd26a`, dirty=true, mode=source. The coordinator independently binds the full source input digest before/after this supervised scenario; this report does not claim the development digest is a clean commit or release.

The supplied context and snapshot consistently name `example-owner/security-fixture`, numeric fixture ID 123, public visibility, main branch and pinned main SHA `aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa`. The project has no Git repository; local `git remote -v` returns exit 128. No actual remote identity could be verified. The snapshot claims complete=true and stable=true and is timestamped 2026-01-01T00:00:00+00:00 through 00:00:01+00:00. Those are synthetic supplied evidence fields, not current independent collection. All 22 passing controls apply only to that evidence. No administrative live access was supplied or attempted.

Before a real readiness decision, select and adopt a separately reviewed exact clean provider release, verify the actual remote identity, retain all stronger existing controls, perform only explicitly authorized remediation, then obtain a complete stable passing live assessment. These future steps were not performed here.

## Executed evidence

Each numbered `.command.json` stores actual argv, working directory, UTC start/end timestamps, duration, exit code, stdout, stderr and the minimal explicit environment. `audit_runner.py` contains the exact orchestration. All validators use the supplied interpreter with `-B`; no environment credentials were read or copied.

| Record | Actual operation | Exit and outcome |
| --- | --- | --- |
| `01-policy.command.json` | Security `--check-policy` | 0; policy passes, public_ready=false; `policy.json` |
| `02-locked-provider.command.json` | Exact provider verifier `--root PROJECT` | 2; unsupported development lock, unverified |
| `03-locked-snapshot.command.json` | Security snapshot with `--project-root PROJECT` | 2; unable-to-verify; `locked-snapshot.json` |
| `04-source-snapshot.command.json` | Security snapshot from selected provider source | 1; two failed controls; `source-snapshot.json` |
| `05-local-tests.command.json` | `unittest discover` of available project tests | 0; 2 executed, 0 failures/errors/skips |
| `06-validation-config.command.json` | Testing configuration validator | 1; missing configuration |
| `07-sdd.command.json` | SDD planning validator | 0; checked=[]; no selected SDD artifacts, not delivery evidence |
| `08-remote-identity.command.json` | Local `git remote -v` | 128; no Git repository |
| `09-record-inputs.command.json` | Read actual Skill, prompt, instructions, context, manifest, lock, index and procedure | 0; source contents retained |

The preliminary exploratory read-only `cat`/`rg` commands are available in the agent tool transcript; unlike the numbered assessment commands, their exact wall-clock timestamps were not separately recorded. A preliminary combined read tried nonexistent `scripts/security/provider.py`; its error was preserved in the transcript, and the actual resolver `scripts/testing/provider.py` was subsequently read and executed. No outcome above is inferred from that failed read.

## Preservation and scope

`project-before.json`, `project-after.json` and `preservation.json` show all seven original project files byte-identical with no additions. All generated files are in the designated separate output directory. No project/provider fix, lock edit, release change, network request, connector, GitHub operation, credentials inspection or delegation occurred. No fixture approval was treated as operational authorization. This is one supervised attempt, with failed and unverified checks retained.

The package validation entry point was not run by this auditing agent: no package change was made, and package success would not establish consumer security. Full package checks and independent scenario replay, if required by the broader change, are coordinator responsibilities and must be reported separately. No executable general consumer project validator exists in the selected provider; required library documentation, compatibility/release/migration policy, operations, observability and CI execution are not comprehensively verified by this focused security audit. SDD empty-selection success and the local tests do not waive those gaps. Agent evals are not indicated by the declared library profile.

The fixture is not an isolation boundary. Command records observe the executed subprocesses but do not supply OS-level telemetry proving absence of every possible external action. Independent coordinator preservation and replay evidence must retain that limitation.
