from pathlib import Path
import subprocess, json, hashlib, datetime, difflib, shutil
import yaml
R=Path('/Users/elviszoz/.codex/worktrees/c379/versat-ai-harness')
P=Path('/private/tmp/versat-public-security-scenarios-r2/public-maintenance-conflict/project')
O=P.parent/'output'
PY='/private/tmp/versat-security-audit-venv/bin/python'
logs=[]
def stamp(): return datetime.datetime.now(datetime.timezone.utc).isoformat()
def run(name,args,cwd=R):
    start=stamp(); p=subprocess.run(args,cwd=cwd,capture_output=True,text=True)
    rec=dict(name=name,argv=args,cwd=str(cwd),started_at=start,finished_at=stamp(),exit_code=p.returncode,stdout=p.stdout,stderr=p.stderr)
    logs.append(rec); (O/'commands.json').write_text(json.dumps(logs,indent=2)+'\n'); print(name,p.returncode,p.stdout[:250],p.stderr[:150],flush=True)
    return p
before={str(f.relative_to(P)):hashlib.sha256(f.read_bytes()).hexdigest() for f in P.rglob('*') if f.is_file()}
(O/'original-hashes.json').write_text(json.dumps(before,indent=2)+'\n')
shutil.copytree(P,O/'rollback')
ctx=json.loads((P/'inputs/context.json').read_text())
identity=yaml.safe_load((P/'.versat/project.yaml').read_text())
lock=yaml.safe_load((P/'.versat/standards.lock').read_text())
index=yaml.safe_load((R/'standards/index.yaml').read_text())
paths=set(index['core']['always'])
for category,value in [('profiles',identity['project']['profile']),('domains',identity['project']['domain']),('criticality',identity['project']['criticality'])]: paths.update(index[category][value])
for tech in identity['technologies']: paths.update(index['technologies'][tech])
resolved=[dict(path=p,digest=hashlib.sha256((R/'standards'/p).read_bytes()).hexdigest()) for p in sorted(paths)]
locked={x['path']:x['digest'] for x in lock['standards']}
match=locked=={x['path']:x['digest'] for x in resolved}
(O/'resolved-standards.json').write_text(json.dumps(dict(identity=identity,resolved=resolved,lock_matches=match,provider_mode='development-source',target=ctx),indent=2)+'\n')
assert match
source=run('source-digest',[PY,'-B','validators/sdd/validate.py','--change','public-repository-security','--input-digest','CHECK-004'])
assert source.returncode==0 and ctx['provider_source_digest'] in source.stdout
run('policy',[PY,'-B','validators/security/validate.py','--check-policy','--output',str(O/'policy-report.json')])
run('current-snapshot',[PY,'-B','validators/security/validate.py','--repository',ctx['repository'],'--snapshot',str(P/'inputs/settings.json'),'--output',str(O/'current-report.json')])
run('render',[PY,'-B','scripts/bootstrap/public_security.py','--output',str(O/'rendered-baseline')])
shutil.copytree(P,O/'proposal')
old=(P/'.github/CODEOWNERS').read_text()
new=old.replace('/special/ @synthetic-specialist','/special/ @synthetic-specialist @elviszoz @evertonspohrversat')
assert new!=old
(O/'proposal/.github/CODEOWNERS').write_text(new)
(O/'migration.diff').write_text(''.join(difflib.unified_diff(old.splitlines(True),new.splitlines(True),fromfile='a/.github/CODEOWNERS',tofile='b/.github/CODEOWNERS')))
snapshot=json.loads((P/'inputs/settings.json').read_text())
snapshot['observations']['codeowners']['data']['rows'][1]['owners']+=['@elviszoz','@evertonspohrversat']
(O/'proposed-synthetic-settings.json').write_text(json.dumps(snapshot,indent=2)+'\n')
run('proposed-synthetic-snapshot',[PY,'-B','validators/security/validate.py','--repository',ctx['repository'],'--snapshot',str(O/'proposed-synthetic-settings.json'),'--output',str(O/'proposed-report.json')])
run('consumer-tests',[PY,'-B','-m','unittest','discover','-s','tests','-v'],cwd=O/'proposal')
after={str(f.relative_to(P)):hashlib.sha256(f.read_bytes()).hexdigest() for f in P.rglob('*') if f.is_file()}
assert before==after
(O/'preservation.json').write_text(json.dumps(dict(original_project_unchanged=True,protection_changed=False,standards_lock_changed=False,public_ready=False),indent=2)+'\n')
(O/'findings.md').write_text('''# Maintenance findings

Target: supplied development source 0.4.0, CHECK-004 digest '''+ctx['provider_source_digest']+'''. This is not an available release or installed-provider adoption. The project is a public Python finance library; canonical index resolution and all locked Standards digests agree. The existing development lock already targets this snapshot and remains unchanged.

The supplied snapshot fails ownership coverage: the later `/special/` row replaces designated owners with the specialist. `migration.diff` proposes retaining the specialist and adding both designated owners on that row. This is a review proposal, not an authorized ownership decision: approval of the shared ownership change remains unresolved. Specialist eligibility was not observed; the supplied evidence only reports administrator permissions for the two designated owners.

Preserve existing classic main protection unchanged: two approvals, owner review, stale-review dismissal, last-push approval, administrator enforcement, no force pushes/deletions, and strict `consumer-security`/`consumer-tests` required checks. Retain existing universal administrator-only branch/tag rules and enabled secret controls. `rendered-baseline` is reference output only; replacing current protections with its one-approval main payload would lose stronger custom requirements. No settings replacement is proposed.

`proposal` retains consumer content, tests, identity and lock; only CODEOWNERS differs. `rollback` retains original project bytes. Restore the original CODEOWNERS to abandon this local proposal; never disable correct remote controls. No capability path or executor-loading changes are required.

The supplied snapshot, policy, renderer, hypothetical corrected snapshot and existing consumer tests were executed with results in `commands.json`. The corrected synthetic snapshot is modeled evidence only, retaining fixture timestamps and commit identifiers; it is not an actual post-change readback. Snapshot mode always has `public_ready: false`. No live access, remote readiness, release, consumer upgrade, profile integration or external operation is claimed. Full package validation is delegated to the coordinator's current run; the consumer has no configured profile validation wrapper, so the two existing tests do not establish full library readiness.

Review ownership, adopt through a governed exact-release migration when available, and obtain separately authorized current live verification after any actual change. Original provider and consumer files were not modified.
''')
print('Artifacts complete',O,flush=True)
