# Public repository security audit

The source verifier reports **fail** for the supplied snapshot of `example-owner/security-fixture` (repository ID 123, public, default branch main). Of 24 controls, 22 passed and two failed. The evidence is a complete, stable synthetic observation from January 1, 2026. Current remote enforcement is unverified and `public_ready` is false.

| Severity | Failed control | Evidence and remediation |
| --- | --- | --- |
| High | `main.dismiss_stale_reviews` | Main's effective review protection allows approvals to survive new reviewable commits. An authorized administrator should enable stale-review dismissal while preserving the existing strict required check and other protections. |
| High | `secrets.secret_scanning_push_protection` | Repository secret scanning is enabled, but push protection is disabled. An authorized administrator should enable push protection and verify the effective setting. |

The applicable contract is `core/public-repository-security.yaml`. The public finance library declares medium criticality and Python. All 14 resolved Standards entries match the provider's version and file digests. The development lock matches the approved CHECK-004 source digest. The installed-provider verifier returned exit 2 because release consumption requires a full commit. A reviewed exact release pin and clean provider are required for installed-consumer verification.

Local policy validation passed and both consumer tests passed. After authorized remediation, rerun the live verifier with administrative read access against the same repository identity. Seven project files retained identical hashes.

The output directory contains command arguments, UTC times, stdout, stderr and exit codes in `commands.json`, the original verifier reports in `policy.json` and `snapshot.json`, and the lock and file comparisons in `resolution.json` and `project-integrity.json`.
