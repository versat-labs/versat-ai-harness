from pathlib import Path
import difflib
import hashlib
import json
import os
import shutil
import subprocess
import sys
import yaml

output = Path(__file__).resolve().parent
project = output.parent / 'project'
provider = Path('/Users/elviszoz/.codex/worktrees/c379/versat-ai-harness')
proposal = output / 'proposal'
commands = {}
env = {'PATH': '/usr/bin:/bin', 'PYTHONDONTWRITEBYTECODE': '1', 'LC_ALL': 'C'}
def record(name, obj):
    (output/name).write_text(json.dumps(obj, indent=2) + '\n')
def digest(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()
def manifest(root):
    return {str(p.relative_to(root)): digest(p) for p in sorted(root.rglob('*')) if p.is_file()}
def run(name, args, cwd, expected):
    cmd = [sys.executable, '-B', *map(str, args)]
    result = subprocess.run(cmd, cwd=cwd, env=env, capture_output=True, text=True, timeout=40)
    for stream in ('stdout','stderr'):
        (output/f'{name}.{stream}').write_text(getattr(result, stream))
    commands[name] = dict(argv=cmd, cwd=str(cwd), exit_code=result.returncode, stdout=f'{name}.stdout',stderr=f'{name}.stderr', environment=env)
    record('commands.json', commands)
    assert result.returncode == expected, name

before = manifest(project)
record('project-before.json', before)
ident = yaml.safe_load((project/'.versat/project.yaml').read_text())
lock = yaml.safe_load((project/'.versat/standards.lock').read_text())
index = yaml.safe_load((provider/'standards/index.yaml').read_text())
paths = set(index['core']['always'])
for name, selectors in [('profiles', [ident['project']['profile']]), ('domains',[ident['project']['domain']]), ('criticality',[ident['project']['criticality']]), ('technologies',ident['technologies'])]:
    for selector in selectors:
        paths.update(index[name][selector])
version = (provider/'VERSION').read_text().strip()
source = json.loads((provider/'docs/validation/public-repository-security/post-merge/CHECK-004.json').read_text())['input_digest_before']
context = json.loads((project/'inputs/context.json').read_text())
assert context['provider_source_digest'] == source and context['provider_version'] == version
assert lock['harness'] == {'version':version,'commit':f'development-snapshot:{source}'}
assert lock['standards'] == [{'digest':digest(provider/'standards'/p),'path':p,'version':version} for p in sorted(paths)]
record('resolution.json', {'identity':ident,'target':lock['harness'],'standards':lock['standards'],'matches_index_and_bytes':True})
run('render', [provider/'scripts/bootstrap/public_security.py','--output',output/'rendered'], provider, 0)
verifier = [provider/'validators/security/validate.py','--repository',context['repository']]
snap = project/'inputs/settings.json'
run('before', [*verifier,'--snapshot',snap,'--output',output/'before-report.json'], provider, 2)
shutil.copytree(project,proposal)
owners = Path('.github/CODEOWNERS')
old = (project/owners).read_text()
wildcard = (output/'rendered'/owners).read_text().splitlines()
baseline = next(line.split()[1:] for line in wildcard if line.startswith('* '))
rows = [line.split() for line in old.splitlines()]
assert rows == [['*',*baseline],['/special/','@synthetic-specialist']]
rows[1].extend(baseline)
new = ''.join(' '.join(row)+'\n' for row in rows)
(proposal/owners).write_text(new)
(output/'migration.patch').write_text(''.join(difflib.unified_diff(old.splitlines(True),new.splitlines(True),fromfile=f'a/{owners}',tofile=f'b/{owners}')))
model = json.loads(snap.read_text())
model['observations']['codeowners']['data']['rows'] = [dict(pattern=row[0],owners=row[1:]) for row in rows]
record('modeled-after.json', model)
run('after', [*verifier, '--snapshot',output/'modeled-after.json','--output',output/'after-report.json'],provider, 0)
run('consumer-tests',['-m','unittest','discover','-s','tests','-v'],proposal,0)
assert before == manifest(project)
assert [p for p,h in manifest(proposal).items() if before.get(p) != h] == [str(owners)]
record('project-after.json',manifest(project))
record('proposal-manifest.json',manifest(proposal))
