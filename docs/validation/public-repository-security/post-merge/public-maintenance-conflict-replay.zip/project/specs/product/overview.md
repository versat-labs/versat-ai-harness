# Synthetic payment library

Provide integrators a pure positive-amount validation helper. Python library, no persistence, credentials, deployment or external services. Product discovery and library profile are already selected for this fixture.
