import unittest

def validate(amount):
    if amount <= 0: raise ValueError('positive amount required')
    return amount

class Amount(unittest.TestCase):
    def test_positive(self): self.assertEqual(validate(1), 1)
    def test_boundary(self):
        with self.assertRaises(ValueError): validate(0)
